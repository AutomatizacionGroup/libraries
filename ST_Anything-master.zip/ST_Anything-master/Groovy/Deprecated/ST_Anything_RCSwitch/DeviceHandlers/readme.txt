Make sure you also get the Virtual Switch Device - VirtualSwitch.device.groovy - 
from the \Groovy\VirtualDevices\ folder.